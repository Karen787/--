import com.mysql.jdbc.Connection;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Random;
import java.util.UUID;

public class Bootstrap {

    public static void main(String[] args) throws Exception {
        insert();
    }

    public static void insert() throws SQLException {
        Random r = new Random();
        String id = UUID.randomUUID().toString();
        String name = "学生";
        String[] sex = new String[]{"男", "女"};
        executeSql(id, name + r.nextInt(9999), sex[r.nextInt(2)]);
    }

    public static void executeSql(String id, String name, String sex) throws SQLException {
        Random r = new Random();
        String dbShardKey = String.valueOf(r.nextInt(2));
        String tableShardKey = String.valueOf(r.nextInt(2));
        Connection con = DBUtil.getConnection("db_" + dbShardKey);
        System.out.println("=== 插入到数据库：" + DBUtil.DBS.get("db_" + dbShardKey));
        System.out.println("=== 插入到表：student_" + tableShardKey);
        String sql = String.format("insert into student_%s values ('%s','%s','%s')", tableShardKey, id, name, sex);
        System.out.println("=== SQL：" + sql);
        PreparedStatement preparedStatement = con.prepareStatement(sql);
        preparedStatement.execute();
        con.close();
        System.out.println("新增成功");
    }
}
