import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class DBUtil {

    static Connection connection = null;
    public final static HashMap<String, String> DBS = new HashMap<>();
    private final static String URL = "jdbc:mysql://localhost:3306/%s?useSSL=false";
    private final static String USER = "root";
    private final static String PASSWORD = "111111";

    static {
        DBS.put("db_0", "simple_sharding_0");
        DBS.put("db_1", "simple_sharding_1");
    }

    public static Connection getConnection(String key) {
        try {
            Class.forName("com.mysql.jdbc.Driver");
            connection = (Connection) DriverManager.getConnection(String.format(URL, DBS.get(key)), USER, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return connection;
    }

    public static void close(Connection connection, PreparedStatement preparedStatement, ResultSet resultSet) {
        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (preparedStatement != null) {
            try {
                preparedStatement.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
